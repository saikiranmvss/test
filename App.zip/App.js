import Skeleton from '@mui/material/Skeleton';
import { useState ,useEffect } from 'react';
import axios from 'axios';
import './App.css';

var arrays='';
export default function App() {
  const [isLoading, setIsLoading] = useState(false);
  const [userss, usersdata] = useState([]);
  

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      const res = await axios.post('http://192.168.0.144:9998/images');
      const json = await res;
      console.log(json.data);
      usersdata(json.data);
      setIsLoading(false);
    };
    fetchData();    
  }, [usersdata]);
return(
<div>  
{  
 isLoading ?  (

  <div>
<div>
  <div className="head-par1"><Skeleton variant="rectangle" className='text-class' /><div className="head-par2" ><Skeleton className='text-par-head1' /><Skeleton className='text-par1' /><Skeleton className='text-par2' /></div></div>
</div>
<div>
  <div className="head-par1"><Skeleton variant="rectangle" className='text-class' /><div className="head-par2" ><Skeleton className='text-par-head1' /><Skeleton className='text-par1' /><Skeleton className='text-par2' /></div></div>
</div>

<div>
  <div className="head-par1"><Skeleton variant="rectangle" className='text-class' /><div className="head-par2" ><Skeleton className='text-par-head1' /><Skeleton className='text-par1' /><Skeleton className='text-par2' /></div></div>
</div>

<div>
  <div className="head-par1"><Skeleton variant="rectangle" className='text-class' /><div className="head-par2" ><Skeleton className='text-par-head1' /><Skeleton className='text-par1' /><Skeleton className='text-par2' /></div></div>
</div>
<div>
  <div className="head-par1"><Skeleton variant="rectangle" className='text-class' /><div className="head-par2" ><Skeleton className='text-par-head1' /><Skeleton className='text-par1' /><Skeleton className='text-par2' /></div></div>
</div>
<div>
  <div className="head-par1"><Skeleton variant="rectangle" className='text-class' /><div className="head-par2" ><Skeleton className='text-par-head1' /><Skeleton className='text-par1' /><Skeleton className='text-par2' /></div></div>
</div>
</div>
):(

  userss.map(function(index){   
   return <h1 className='text-class' key={index.user_id}>{index.test10}</h1>
})

  // <img key={index} src={process.env.PUBLIC_URL+index} width={200} height={200} />

)
}
</div>  
)

}